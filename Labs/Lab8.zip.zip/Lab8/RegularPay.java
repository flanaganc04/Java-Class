package CS201.Labs.Lab8;

public class RegularPay extends PayCalculator {
    
    public RegularPay() {
       super();
    }

    public RegularPay(double newPay, double newHours){
        super(newPay, newHours);
    }
 
}
